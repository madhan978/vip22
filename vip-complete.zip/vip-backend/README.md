# VIP Backend – contact form API

Receives enquiries from the website form and emails them to you.

## 1. Install
Requires Node.js 18 or newer (https://nodejs.org).

    npm install

## 2. Configure
1. Copy `.env.example` to `.env`.
2. Fill in the values.
3. Gmail App Password: Google Account > Security > turn on 2-Step Verification,
   then Security > App passwords > create one and paste it as `MAIL_PASS`.

## 3. Run

    npm start

Check http://localhost:3000 – you should see `{"status":"ok"}`.

## 4. Connect the website
In `vip.js` set:

    const FORM_ENDPOINT = "http://localhost:3000/api/contact";

`SITE_URL` in `.env` must match the address the page is opened from
(for example `http://127.0.0.1:5500` with VS Code Live Server), or the
browser will block the request (CORS).

## 5. Deploy (Render example)
1. Push this folder to GitHub (`.env` is git-ignored, so your secrets stay private).
2. On render.com create a new Web Service from the repo.
   Build command: `npm install`   Start command: `npm start`
3. Add `SITE_URL`, `MAIL_USER`, `MAIL_PASS`, `MAIL_TO` under Environment.
4. Set `FORM_ENDPOINT` in `vip.js` to `https://YOUR-SERVICE.onrender.com/api/contact`
   and set `SITE_URL` to your live website address.

Note: free Render services sleep when idle, so the first enquiry after a
quiet period can take ~30 seconds.

## Built-in protection
- CORS: only your website can call the API
- Rate limit: 5 enquiries per visitor per 15 minutes
- Input limits, email validation and header-injection protection
