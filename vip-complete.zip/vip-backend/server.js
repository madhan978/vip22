require("dotenv").config();

const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const nodemailer = require("nodemailer");

const { MAIL_USER, MAIL_PASS, MAIL_TO, SITE_URL, PORT = 3000 } = process.env;

if (!MAIL_USER || !MAIL_PASS || !MAIL_TO) {
  console.error("Missing MAIL_USER, MAIL_PASS or MAIL_TO. Copy .env.example to .env and fill it in.");
  process.exit(1);
}

const app = express();
app.set("trust proxy", 1); // needed on Render/Railway so rate limiting sees the real visitor IP

app.use(express.json({ limit: "10kb" }));

// Only your website(s) may call this API. Separate several with commas.
const allowedOrigins = (SITE_URL || "").split(",").map((s) => s.trim()).filter(Boolean);
app.use(
  cors({
    origin: allowedOrigins.length ? allowedOrigins : false,
    methods: ["POST"],
  })
);

const contactLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5, // 5 enquiries per visitor per 15 minutes
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests. Please try again later." },
});

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: { user: MAIL_USER, pass: MAIL_PASS },
});

const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const clean = (v, max) => String(v || "").trim().slice(0, max);

app.get("/", (req, res) => res.json({ status: "ok" }));

app.post("/api/contact", contactLimiter, async (req, res) => {
  const name = clean(req.body?.name, 100);
  const email = clean(req.body?.email, 150);
  const subject = clean(req.body?.subject, 150).replace(/[\r\n]+/g, " "); // blocks header injection
  const message = clean(req.body?.message, 5000);

  if (!name || !email || !subject || !message) {
    return res.status(400).json({ error: "All fields are required." });
  }
  if (!isEmail(email)) {
    return res.status(400).json({ error: "Please enter a valid email address." });
  }

  try {
    await transporter.sendMail({
      from: `"VIP Website" <${MAIL_USER}>`,
      to: MAIL_TO,
      replyTo: `"${name.replace(/["\r\n]/g, "")}" <${email}>`, // Reply answers the visitor
      subject: "Website enquiry: " + subject,
      text: `Name: ${name}\nEmail: ${email}\nSubject: ${subject}\n\n${message}`,
    });
    res.json({ ok: true });
  } catch (err) {
    console.error("Mail error:", err.message);
    res.status(500).json({ error: "Could not send your message." });
  }
});

app.listen(PORT, () => console.log(`VIP backend running on port ${PORT}`));
