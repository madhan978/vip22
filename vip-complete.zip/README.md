# VIP website + backend – quick start

Folders
- website/      index.html, style.css, vip.js  (add your images: p.jpeg, insta.png, facebook.png, whatsapp.png)
- vip-backend/  the contact-form server

Run locally
1. cd vip-backend
2. npm install
3. copy .env.example to .env and fill in MAIL_USER, MAIL_PASS (Gmail App Password), MAIL_TO
4. npm start        (should print: VIP backend running on port 3000)
5. Open website/index.html with VS Code "Live Server" (http://127.0.0.1:5500)
6. Submit the form – the email arrives in MAIL_TO

Going live
- Deploy vip-backend (see its README), then in website/vip.js set FORM_ENDPOINT to
  https://YOUR-BACKEND-URL/api/contact
- In the backend's environment set SITE_URL to your live website address.
